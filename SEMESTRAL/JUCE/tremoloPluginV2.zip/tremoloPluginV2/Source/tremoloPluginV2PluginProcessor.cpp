#include "../JuceLibraryCode/JuceHeader.h"

#include "tremoloPluginV2.h"
#include "tremoloPluginV2_types.h"

#if JUCE_VERSION >= 0x050400
using Parameter = AudioProcessorValueTreeState::Parameter;
#endif

struct onParamChangeListener : AudioProcessorValueTreeState::Listener
{
    onParamChangeListener(tremoloPluginV2StackData* sd) : SD(sd)
    {
    }

    void parameterChanged (const String& parameterID, float newValue) override
    {
        const int idx = getParameterIndex(parameterID);
        onParamChangeCImpl(SD, idx, static_cast<double>(newValue));
    }
    
private:
    int getParameterIndex (const String& parameterID)
    {
        (void)parameterID;
    
        if (parameterID == "Rate") {
            return 0;
        }
        if (parameterID == "Depth") {
            return 1;
        }
        if (parameterID == "Waveform") {
            return 2;
        }
    
        return (-1);
    }    
    
    tremoloPluginV2StackData *SD;
};

//==============================================================================
class tremoloPluginV2AudioProcessor  : public AudioProcessor
{
    //==============================================================================
#if JUCE_VERSION >= 0x050400
    const StringArray m_choices3;

public:
    tremoloPluginV2AudioProcessor()
        : paramListener(&mStackData),
          m_choices3({ "sine", "square" }),
          parameters(*this, nullptr, "tremoloPluginV2", {
                std::make_unique<Parameter>("Rate", "Rate", "",
                    NormalisableRange<float>(0.1f,10.f,[](float min, float max, float norm) {return min*powf(max/min,norm);}, [](float min, float max, float val) {return logf(val/min)/logf(max/min);}), 1.f, [](float val) {return String(val, 3);}, nullptr),
                std::make_unique<Parameter>("Depth", "Depth", "",
                    NormalisableRange<float>(0.f,1.f), 1.f, [](float val) {return String(val, 3);}, nullptr),
                std::make_unique<Parameter>("Waveform", "Waveform", "",
                    NormalisableRange<float>(0.f, m_choices3.size()-1.f, 1.f), 0.f,
                    [=](float value) { return m_choices3[(int) (value + 0.5)]; },
                    [=](const String& text) { return (float) m_choices3.indexOf(text); }, false, true, true) })

    {
        mStackData.pd = &mPersistentData;
        
        tremoloPluginV2_initialize(&mStackData);

        createPluginInstance(&mStackData, reinterpret_cast<unsigned long long>(this));

        parameters.addParameterListener("Rate", &paramListener);
        parameters.addParameterListener("Depth", &paramListener);
        parameters.addParameterListener("Waveform", &paramListener);

    }
    //==============================================================================
#else // For JUCE prior to 5.4.0
public:
    tremoloPluginV2AudioProcessor()
    :   paramListener(&mStackData), parameters (*this, nullptr)
    {
        mStackData.pd = &mPersistentData;
        
        tremoloPluginV2_initialize(&mStackData);

        createPluginInstance(&mStackData, reinterpret_cast<unsigned long long>(this));

        //
        // Parameter property Rate
        //
        parameters.createAndAddParameter ("Rate", "Rate", "",
            NormalisableRange<float>(0.1f, 10.f, 
                [](float min, float max, float norm) {return min * powf(max/min, norm);},
                [](float min, float max, float val) {return logf(val/min)/logf(max/min);} ),
            1.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("Rate", &paramListener);

        //
        // Parameter property Depth
        //
        parameters.createAndAddParameter ("Depth", "Depth", "",
            NormalisableRange<float>(0.f, 1.f), 1.f,
            [](float val) {return String(val, 3);},
            nullptr);
        parameters.addParameterListener("Depth", &paramListener);

        //
        // Parameter property Waveform
        //
        const StringArray choices3({ "sine", "square" });
        parameters.createAndAddParameter ("Waveform", "Waveform", "",
            NormalisableRange<float>(0.f, choices3.size()-1.f, 1.f), 0.f,
            [=](float value) { return choices3[(int) (value + 0.5)]; },
            [=](const String& text) { return (float) choices3.indexOf(text); },
            false, true, true);
        parameters.addParameterListener("Waveform", &paramListener);

        parameters.state = ValueTree(Identifier("tremoloPluginV2"));
    }
#endif

    //==============================================================================
    ~tremoloPluginV2AudioProcessor()
    {
        tremoloPluginV2_terminate(&mStackData);
    }
    
    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override
    {
        (void)samplesPerBlock;
        resetCImpl(&mStackData, sampleRate);
        setLatencySamples(getLatencyInSamplesCImpl(&mStackData));
    }

    void releaseResources() override                { }
    
    
    void processBlock (AudioBuffer<double>& buffer, MidiBuffer& midiMessages) override
    {
        (void)midiMessages;
        ScopedNoDenormals noDenormals;
        int nSamples = buffer.getNumSamples();
        int nChannels = buffer.getNumChannels();
        const double** pin = buffer.getArrayOfReadPointers();
        double** pout = buffer.getArrayOfWritePointers();
        const double** inputs = pin;
        double** outputs = pout;
        int i_;

        tremoloPluginV2StackData *SD = &mStackData;

        const double* pinputs[2]{};
        double* poutputs[2]{};

        if (nChannels < 2) {
            tempBuffer.setSize(2-nChannels, nSamples);
        if (nChannels < 2) {
                tempBuffer.clear(0, nSamples);
                inputs = pinputs;
                for (i_ = 0; i_ < nChannels; i_++) {
                    inputs[i_] = pin[i_];
                }
                const double** p = tempBuffer.getArrayOfReadPointers();
                for (i_ = nChannels; i_ < 2; i_++) {
                    inputs[i_] = p[i_-nChannels];
                }
            }
            if (nChannels < 2) {
                outputs = poutputs;
                for (i_ = 0; i_ < nChannels; i_++) {
                    outputs[i_] = pout[i_];
                }
                double** p = tempBuffer.getArrayOfWritePointers();
                for (i_ = nChannels; i_ < 2; i_++) {
                    outputs[i_] = p[i_-nChannels];
                }
            }
        }

        int osz0_;
        int osz1_;
        if (nSamples <= MAX_SAMPLES_PER_FRAME) {
            /* Fast path for common frame sizes. */
            int isz0_ = nSamples;
            int isz1_ = nSamples;
            processEntryPoint(SD, (double)nSamples,
                    inputs[0], &isz0_,
                    inputs[1], &isz1_,
                    outputs[0], &osz0_,
                    outputs[1], &osz1_);
        } else {
            /* Fallback for unusually large frames. */
            int isz0_ = MAX_SAMPLES_PER_FRAME;
            int isz1_ = MAX_SAMPLES_PER_FRAME;
            int n = MAX_SAMPLES_PER_FRAME;
            for (i_ = 0; i_ < nSamples; i_ += MAX_SAMPLES_PER_FRAME) {
                if (i_ + MAX_SAMPLES_PER_FRAME > nSamples) {
                    n = nSamples - i_;
                    isz0_ = nSamples - i_;
                    isz1_ = nSamples - i_;
                }
                processEntryPoint(SD, (double)n,
                        inputs[0]+i_, &isz0_,
                        inputs[1]+i_, &isz1_,
                        outputs[0]+i_, &osz0_,
                        outputs[1]+i_, &osz1_);
            }
        }

    }
    
    void processBlock (AudioBuffer<float>& buffer,  MidiBuffer& midiMessages) override
    {
        (void)midiMessages;
        AudioBuffer<double> doubleBuffer;
        doubleBuffer.makeCopyOf(buffer);
        processBlock(doubleBuffer, midiMessages);
        buffer.makeCopyOf(doubleBuffer);
    }
    
    //==============================================================================
    bool hasEditor() const override                 { return true; }
    AudioProcessorEditor* createEditor() override;
    
    //==============================================================================
    const String getName() const override           { return JucePlugin_Name; }

    bool acceptsMidi() const override               { return false; }
    bool producesMidi() const override              { return false; }
    bool isMidiEffect () const override             { return false; }
    double getTailLengthSeconds() const override    { return 0.0;   }

    //==============================================================================
    // NB: some hosts don't cope very well if you tell them there are 0 programs,
    // so this should be at least 1, even if you're not really implementing programs.
    int getNumPrograms() override                       { return 1;  }
    int getCurrentProgram() override                    { return 0;  }
    void setCurrentProgram (int index) override         { (void) index; }
    const String getProgramName (int index) override    { (void) index; return {}; }
    void changeProgramName (int index, const String& newName) override  { (void) index; (void) newName; }
    
    //==============================================================================
    void getStateInformation (MemoryBlock& destData) override
    {
        auto xml (parameters.state.createXml());
        copyXmlToBinary (*xml, destData);
    }
    
    void setStateInformation (const void* data, int sizeInBytes) override
    {
        auto xmlState (getXmlFromBinary (data, sizeInBytes));
        if (xmlState != nullptr)
            if (xmlState->hasTagName (parameters.state.getType()))
                parameters.state = ValueTree::fromXml (*xmlState);
    }
    
    bool supportsDoublePrecisionProcessing() const override  { return true; }
    
private:
    //==============================================================================
    static const int MAX_SAMPLES_PER_FRAME = 4096;

    tremoloPluginV2StackData mStackData;
    tremoloPluginV2PersistentData mPersistentData;
    onParamChangeListener paramListener;
    AudioBuffer<double> tempBuffer;
    
    //==============================================================================
    AudioProcessorValueTreeState parameters;
 
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (tremoloPluginV2AudioProcessor)
};

//==============================================================================
// This creates new instances of the plugin..
AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new tremoloPluginV2AudioProcessor();
}

#include "tremoloPluginV2PluginEditor.h"

AudioProcessorEditor* tremoloPluginV2AudioProcessor::createEditor()
{
    return new tremoloPluginV2AudioProcessorEditor(*this, parameters);
}

