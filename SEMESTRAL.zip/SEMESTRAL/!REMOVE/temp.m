
% plot a

