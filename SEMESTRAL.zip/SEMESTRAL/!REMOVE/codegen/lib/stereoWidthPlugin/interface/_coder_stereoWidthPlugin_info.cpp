//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_stereoWidthPlugin_info.cpp
//
// Code generation for function 'onParamChangeCImpl'
//

// Include files
#include "_coder_stereoWidthPlugin_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[10]{
      "789ced5a416fe344147e812da045401609b4c73d212ebb6ed36d92e556a56d48b5db984d"
      "daae5aad1ac79e266eedb1e399b4311237ee08897fc03f00c1990307"
      "8e1c39ee8dbf80c485719c491a7707a74debd6de79923b79f366def7de4cfce6d3a490ab"
      "3dcb01c08710ca5f5f84ed07233d3f6adf826989da73a3f66e44e7b2",
      "0077a6e671fb77a356773045031a2a58b3d178a6e1d826d6306dfa2e020f11c73a41c6d0"
      "72685aa869daa87156d90a347be38c69ac04a6e073a58bf4e346df06"
      "af4b26115a6795c97a08f2bd33e37a9c0ad6231fb1efafbf545ccf3cd128524e344f3974"
      "2c037944e9790a392a2d0d8e970605428c2776cf770b25c33bfd7a31",
      "900e569a0a75974b85f262f971e9a05c5a5939788c8aed03cd28a28376a980ca8b4b2bed"
      "72bba43858d53ccdae7435dc41959aed5a8fec719e8339f3bc179327"
      "b7771055ad7ec7c4354ca88675becf3c8ed625e3888a280e2e57b5bf273178dc9ec0fe9e"
      "5b5ab6bdb1ebfad18c7946dbc9f8f786edcfefffa4076d5278a5dfbe",
      "5d48128fcb4de1cdfb7e7e2ac0cb47ecfd825b3e555fd4db5f6956b9bab3d9f357fdcac6"
      "240e3506272e0e10e849f94fac9e57aefd7d67fe4c7614aef60dd309"
      "5ffc1ba8e784220f39bba641bb610ca3fe9baae7f77397c3e3fef705783cdf5fc7e32af0"
      "1214d806028c96b0bf0a3042c11e130cf628b0060ee8d0673d0830d0",
      "e1881df021f7761f8e411b6a0df67ddf649f96e1013c64cf1e9b69b3d1c17c159a6cc464"
      "d4c3714f03d6e1197b1a4c7f0eabf094f5118610c48118eaee30060a"
      "5d36c3621174988ee111f39c5cfdfaf16eb2e7c1dffffef220493c2e693d0f3e11e0e523"
      "76ff89a16efa74b0bd5bdfad17e9e69e815608c8f3206dfc6fdeefcb",
      "c7317972fbf94329ec4f2bbf4fcb79df12e491567effd90fc7ef2489c725adf57c567edf"
      "ed6d14aacf55a2958b6ab34b0eab6b5be4c55a76eaf99f82f9b3aea3"
      "23f09f8fd813a8e71e2288ca7b9a50de9473ba25c823ad755cded38422ef692ee6bf2598"
      "7f5df5e5b278dcff82102fb40c8b39dc3e3efef99cf7256d411cfc1c",
      "f97dd4ee433d953726b9e18820623ab56e2dc1ba64a58e651d2fa93abdbdb7b553ac36d6"
      "8eb6beec6d1f757c555b56f56a76ea74867899eb393a22641d53cf57"
      "1d13d3abbc3f91bcfbf57892775f0f9ee4dda148de7d31ff2dc1fcdbcabbdf15e2859651"
      "51cf1cef360471f073e48f519b5edeedb231415c01fb266f4c1dcb3a",
      "9ee4dd57e3ff9560feacebe80bfce723f6047899ee21e6fd3c359bca57f2ef8be149fecd"
      "c74bfe9d049ee4df57e3ff9560feacebf88dc07f3e624fe67d7fcadc"
      "63ddafe18666bb1622fcd74c59d7655d9f2d4f59d7439175fdff71e2e200819ed57b9579"
      "f7ed7e0c1eb7bfa6c8d7305d2edcb6fb967fe68ce3fb9838b87dbf7e",
      "33ff0898136d044caf434b906756ea55d6f1e4fdc97cfeff03b4acde51",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 15088U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 5, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("onParamChangeCImpl"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp37280847_8755_4e6b_ad6e_b72e8015b8b7/onParamChangeCImpl.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.98596064816));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("resetCImpl"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath",
                emlrtMxCreateString(
                    "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
                    "tp37280847_8755_4e6b_ad6e_b72e8015b8b7/resetCImpl.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.98596064816));
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 2, "Name",
                emlrtMxCreateString("processEntryPoint"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp37280847_8755_4e6b_ad6e_b72e8015b8b7/processEntryPoint.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.98596064816));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 3, "Name",
                emlrtMxCreateString("createPluginInstance"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp37280847_8755_4e6b_ad6e_b72e8015b8b7/createPluginInstance.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.98596064816));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 4, "Name",
                emlrtMxCreateString("getLatencyInSamplesCImpl"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 4, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp37280847_8755_4e6b_ad6e_b72e8015b8b7/getLatencyInSamplesCImpl.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.98596064816));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2049777 (R2022b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("UDDiUEYMdylxnobDCM9QQH"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_stereoWidthPlugin_info.cpp)
