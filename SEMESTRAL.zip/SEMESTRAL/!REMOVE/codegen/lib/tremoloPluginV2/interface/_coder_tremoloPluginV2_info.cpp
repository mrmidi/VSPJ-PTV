//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_tremoloPluginV2_info.cpp
//
// Code generation for function 'onParamChangeCImpl'
//

// Include files
#include "_coder_tremoloPluginV2_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[10]{
      "789ced5acd6edb46101eb531fa03d4517a28829c8202058a0209ab3fcb2a727125db9191"
      "d84c651b498cc0a4a9b54c9b5c52e44a320bf4198abe411fa097e609"
      "7ae8a1c71e7b299047e8b1c72e45ae6cd1d95236655a6276006a359cddf96686e2ec87b5"
      "21d77c9a03804508e48f6f82f19350cf87e37b302e517b2e1c3f8ee8",
      "4c16e0d6d83a66ff311c350b13744a0205ab261aad6c5ba68e554cb63d1b81835ccbe8a3"
      "f6d072a81b685b3751ebbcb2e96be6da39d348f14dfef7fa11d24e5a"
      "3d139c23f72c42e3bc32aac75f9c7c6f4d588f01a71ef9887d6ff595643b7a5f2548eaab"
      "8e7468196de4b852d791dce36ae1f4a4705a74dd76cdec7a76b1da76",
      "06df7fed4b074bdb12b18bb5760595ab95fd626db9b05fae152afb07d51ada2fabb552f5"
      "70b9522a97cb928565d551cdfa918a3ba8de346de3a139caf334619e"
      "7762f264f60e22b2d1ebe8b8895da2628d3d67168772c538a2c28b83c9b49e6f3f068fd9"
      "5378be174a4b1f6f6c5d6f4f9867743c9bffe170fcfca3d79a3fa685",
      "f7d52f0bf934f198dc145ed2f7f3330e5e3e62ef15ede581fc7cebe0996a2cafef6e74bd"
      "15afbe7616871c8313170770f4b4fca7d6cfebd7febe537f3add0a57"
      "7a6ddd0a5efc73fddc4e98e7ed881ecd93d989834ccb08f1778b37d6c7efe6ae86c7fcbf"
      "e0e0b17deb7538ee411d5e81043be002a523f453024a24e8a5439b5e",
      "1234c0020d7af40e020c643863173cc8bddf831350875a8bfece37e8b712dc8707f47a49"
      "579a74b6bf5e866d3ae36cd683d19d16acc2537ab5a8fe1dacc0137a"
      "8f506c44d75a60d04ba69f3de8503f98ae28c2436a19af93c2a9c3b4fad617fffc9aea3e"
      "70efe7c5c534f198647d1fe837f5c6a05ade187cbb5ac5cf2a4baef3",
      "7c89ac8b7d60de785fd2dfcba7317932fbc5cd28b83fafbc7e5ef6798593c7bcf2fac77f"
      "3fba93261e93acf7f302e91aeb6b2b2f3606bdcd16a9ba837aad411a"
      "d9e9e77f72d64f5a478be33f1fb1a7d0cf1de42222ce67027957f6698593c7bcf671713e"
      "1388389fb99c7f85b3febafacb55f198ff052e5e60193673983d3e7e",
      "3fe17989c28983ed23bf85e31e6ccddd89496e38c38f96bc33fd2beb7869f5e79d979bbb"
      "4bebadc6f1e6e3eece71c793d592ac89739359e463b66369c8755731"
      "713cd9d23199e6b989e0db6fc7137cfb7af004df0e44f0edcbf95738eb67956f7fc0c50b"
      "2c61539f39befd6542be7dc08983ed23bf87e37cf26d9bcef163f259",
      "b73b5637855397acf4b1ace309de3d1dff6f38eb27ada3c7f19f8fd853e0659a83a8f78b"
      "d46c2c5fc1bf2f8727f8379b2ff8771a78827f4fc7ff1bcefa49ebf8"
      "03c77f3e624fe77d7f42dd63cd6be2966ada0672d95f31455f177d7db23c455f0f44f4f5"
      "ffc7898b03387a56cf55923eb7bb3178ccfe9626dfc4a4549cb5f396",
      "7f13c6f1534c1cccbeb77533ff0098e33d0818af83c2c9332bfd2aeb78e2fc2499ffff00"
      "6545cb55",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 15072U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 5, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("onParamChangeCImpl"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp29d5e475_2981_4915_b79e_4a937f853444/onParamChangeCImpl.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.97835648153));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("resetCImpl"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath",
                emlrtMxCreateString(
                    "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
                    "tp29d5e475_2981_4915_b79e_4a937f853444/resetCImpl.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.97835648153));
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 2, "Name",
                emlrtMxCreateString("processEntryPoint"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp29d5e475_2981_4915_b79e_4a937f853444/processEntryPoint.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.97835648153));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 3, "Name",
                emlrtMxCreateString("createPluginInstance"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp29d5e475_2981_4915_b79e_4a937f853444/createPluginInstance.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.97835648153));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 4, "Name",
                emlrtMxCreateString("getLatencyInSamplesCImpl"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 4, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp29d5e475_2981_4915_b79e_4a937f853444/getLatencyInSamplesCImpl.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(738887.97835648153));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2049777 (R2022b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("bO0YzIyJi654tnuaWDbDgH"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_tremoloPluginV2_info.cpp)
