//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_tremoloPluginV2_info.h
//
// Code generation for function 'onParamChangeCImpl'
//

#ifndef _CODER_TREMOLOPLUGINV2_INFO_H
#define _CODER_TREMOLOPLUGINV2_INFO_H

// Include files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
// End of code generation (_coder_tremoloPluginV2_info.h)
