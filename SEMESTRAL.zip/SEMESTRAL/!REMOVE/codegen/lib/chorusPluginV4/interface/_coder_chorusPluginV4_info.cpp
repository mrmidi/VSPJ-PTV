//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_chorusPluginV4_info.cpp
//
// Code generation for function 'onParamChangeCImpl'
//

// Include files
#include "_coder_chorusPluginV4_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[10]{
      "789ced5acd6fd348147fd905ed6a25bad9458b90b8f4b817ea3609fd805349bf52fa6148"
      "52b15455e2d893c48d3d76fd91d62b71e11f58adf843e0d22368c51d"
      "8923474efc0d1c99c499347599755ab76e63e649cee4f9cdbcdf7b33f66f9e268154613d"
      "050063e0cb7ff7fdf6464f4ff7da1fe0b804eda95efb4b40a7721dae",
      "1d1b47edfff45ad9c00e3a707c054b3aea8f540c5dc512764a9e89c042b6a1b591d2b5d4"
      "550d95541d1507958d8ea62f0d98fa4ac7d4f99e6f22b9557475b09a"
      "f65184daa0d29f8f8f8c7caf0d391ffb8cf94807ecdb8b3b8269a96dc941425bb284baa1"
      "29c8b2853d4bb07767a60e5a530719db56e6f43dcfcccc28d6fedf93",
      "1d6960a12438662d939d9caee5ea955a5dae5572f7b2f72ab339a55e99cbc973532893cb"
      "66e6a604038b9225e9f9a6841b285fd04d6d42efe7791031cfdf42f2"
      "a4f6067244cd6da8b8806d47c2325d671a47f58c710485150795f35adf76081eb5c7b0be"
      "27a6962c6fe8bcfe3a649ec1f6a8ffcfddf6b37a2877dab8f0de1fbe",
      "b91f271e95cbc28bfa7ede62e0a503763763ceee8b4f376b8f256d76796b75cf9bf7f24b"
      "4771882138617100438fcb7f6c7c9ebff0f79df853c95638ef2aaae1"
      "bff8037c6e46cc732ca007f3a476b96958aeedc36fe52e8fc7d3a9b3e151ff4f197874df"
      "7add6bb7210f3b2040196c20e508f914801412e452412197000b6080",
      "0c2eb9830083d3edb1051ea47e74a10552572b92e77c957ccbc238dc25d733325227bd3b"
      "e34528911e47bdeef6ef146111d6c95524fa13988735724f8626c1b3"
      "089e4dfa69a46d102f98f4cfc104e8b1f1d566255efe375ebeba13271e95a4f3fffa9a6d"
      "96ca8bad25b7fd97fe44f79a52e1a1b4c0f97fd4eabda8cfcbef2179",
      "52fbc94dc8bf3faaf5fca8ecef55461ea35acfcfdc7cf1204e3c2aa3cae77f30f0d201bb"
      "bc32bd61b5c49a36bff468df6d2ae5c9e9c9122487cf3f30c60f3b8f"
      "06c37f3a608f81cf2d6423879fcbf8f2bdecd355461ea3cae3fc5cc6177e2e733aff55c6"
      "f88be297b3e251ffd79978bea54be670f5eaf1f188e72415461c741f",
      "79db6bb76173c44e4a52c486bab10eae5b95311f49e1afa4e3c5c5cfe5671b5bd3cbc585"
      "dd8d95bdf26ec313a5ac282f27879f13548f99962123db5ec48ee589"
      "868a9df33c37e1f5f6b7f178bd7d3178bcdef685d7dba7f35f658cbfaaf5f64f4c3cdfd2"
      "23f52b576fff19b1de961871d07de45daf1dc57adb24d64e449daa9b",
      "fef7ea7be1b1a4e3f1bafb7cfc7f628c1f761e3d86ff74c01e435d265b88783f599a1dcb"
      "97d7dfa7c3e3f537edcfebef38f078fd7d3efe3f31c60f3b8fcf19fe"
      "d3017b3ceffb1a718f65af808b926e6ac8a6bf62725ee7bc3e5c9e9cd77de1bcfeff3861"
      "7100434feab94ad475bb1d8247eddf20f90276b299ab76def225621c",
      "ff86c441eddb9b97f307c0146b21e0f83c5419792685af928ec7cf4fa2f9ff0ad0ebe3f"
      "e",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 15064U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 5, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("onParamChangeCImpl"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tpb2306b4f_bfcb_4535_84df_94c91e243291/onParamChangeCImpl.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738890.540636574));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("resetCImpl"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath",
                emlrtMxCreateString(
                    "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
                    "tpb2306b4f_bfcb_4535_84df_94c91e243291/resetCImpl.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(738890.540636574));
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 2, "Name",
                emlrtMxCreateString("processEntryPoint"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tpb2306b4f_bfcb_4535_84df_94c91e243291/processEntryPoint.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(738890.540636574));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 3, "Name",
                emlrtMxCreateString("createPluginInstance"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tpb2306b4f_bfcb_4535_84df_94c91e243291/createPluginInstance.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(738890.540636574));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 4, "Name",
                emlrtMxCreateString("getLatencyInSamplesCImpl"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 4, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tpb2306b4f_bfcb_4535_84df_94c91e243291/getLatencyInSamplesCImpl.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(738890.540636574));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2049777 (R2022b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("nptFnN35pGyZ4uvF7LLHuH"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_chorusPluginV4_info.cpp)
