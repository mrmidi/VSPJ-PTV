//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_Chorus_info.cpp
//
// Code generation for function 'onParamChangeCImpl'
//

// Include files
#include "_coder_Chorus_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[7]{
      "789ced594d73d240185e9c3a7251d183e3d99b17235f2d1c2b02e2078d03adda8e034bb2"
      "81d0641392f01167fc0d8e377f87e7fe082fce78eccff06868583e42"
      "d7048154e8be979797877d3fd967170222a5371100c01de0cae0b1ab6f8fecd848df00b3"
      "e2c523237dcb6313b9097666d611fccb480b1ab6d0c0720d0c55345e",
      "296aaa8c21b6aab68e80814c4de921f10291640555651555a68df2d0520b53d0d81842c3"
      "d7b916124e2b5d15182d7392a1326d8cfbf18b52ef4ec07ef429fd88"
      "79f093fc474e37e41eb410d7830627698a880c93eb189cd9de8b0f4ee38384698a59b563"
      "eb893dd1e87f7a3a9426e6aa9ca5a74494cc40295d4b4a30554b0982",
      "546ba41bf15a3ae900289e4d89bb294ec33c34a09a6b41dc44b992aa2b4fd4c9dc97acf3"
      "9e4f9d046f228b57ba4d1997b069412c9039933ceaff988757687910"
      "59d57c7b3ef1081ec27ce75aeb8cd7b7af7703d6e9d593cf472ff4b747df85a10e2bded9"
      "cf4834cc7844ae2adeb2fbf301255ecc8377137aa6cfbf3f68bc854a",
      "a678f4b263efdbb9c2240fde278e5f1e806287e5ffbaecf765bf2ff77dea24b85394ec9c"
      "c7fb5d51d6dc6cdcf73795cf039fd7b9b5cf77beb553e7759d52c7a6"
      "f279f4accff81cac9ecf3fe45f898363f42e9d95d2c58c8a0a956ca5f06c7bf8fc07657d"
      "d03e6a14ff310f1e029f3bbf6d90c5eee5ae5c9773ba4ea96353799c",
      "ddcb5d61f7f2c5fc6fd17ed70d4d40a699c79661f39a8cad55decb199f5f1e8ff1f97ae2"
      "313e7785f1f962fecf29eb83f6d1a6f88f79f010f6bb6020c7fbfc96"
      "9fa997f1fa62f118af93cf335e0f231ee3f5d5f83fa7ac0fdac7cf14ff310f1ece7e7fed"
      "b8c7825dc215a8ea0a32c9bf2f8cd719af07ab93f1ba2b8cd7ff1ec7",
      "2f0f40b1c3f25fa7ac5f17bf2c3bb7873ef1087e09c997b0954cfc6fcf497f2f99c7579f"
      "3c087e7270350f2e23b44180d93ed429756e0b5f6d7bbcb0f8f8f0b8"
      "7cb45bac3c6f975f740edb4d9b87495e286e3e1fff011fd70ea7",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 10640U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 5, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("onParamChangeCImpl"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp4de38af5_3fa4_4ccf_b5b1_53de3e194d64/onParamChangeCImpl.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738888.05379629624));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("resetCImpl"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath",
                emlrtMxCreateString(
                    "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
                    "tp4de38af5_3fa4_4ccf_b5b1_53de3e194d64/resetCImpl.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(738888.05379629624));
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 2, "Name",
                emlrtMxCreateString("processEntryPoint"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp4de38af5_3fa4_4ccf_b5b1_53de3e194d64/processEntryPoint.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(738888.05379629624));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 3, "Name",
                emlrtMxCreateString("createPluginInstance"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp4de38af5_3fa4_4ccf_b5b1_53de3e194d64/createPluginInstance.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(738888.05379629624));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 4, "Name",
                emlrtMxCreateString("getLatencyInSamplesCImpl"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 4, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp4de38af5_3fa4_4ccf_b5b1_53de3e194d64/getLatencyInSamplesCImpl.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(738888.05379629624));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2049777 (R2022b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("MVGQTGT764HBH0EwnGlohE"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_Chorus_info.cpp)
