//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_phasePlugin_info.cpp
//
// Code generation for function 'onParamChangeCImpl'
//

// Include files
#include "_coder_phasePlugin_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[9]{
      "789ced5add52d340143ef5679471d4ea8572c90b60680bb45e62295884122c7454466948"
      "b66d20d9a449fa13677c06c667f04e2f7c007d08c72beff431bc74db"
      "740b0dae2914028d7b66d2edc9d93ddf39679b2f67760ab1fc5a0c00ee80279373de78bb"
      "a7c77be3151814bf3dd61b277c3a95eb706d601db51ff446d9c00e6a",
      "3b9e82251df5572a86ae62093b9bae89c042b6a13591d2b554540d6daa3a2a1e550a1d4d"
      "5f3a62ea2b1d53e77bb686e4fd624307ab661f46a81d55faf5f8c1c8"
      "f7da90f56831ea11f7d9b773af05d3529b928384a6640915435390650b754bb0f7d289f6"
      "7ea29db46de5b15e77cd645ab15a6f673a52c5c2a6e098b399ca4c72",
      "5e49ed2432bbd2ce6c653ebdb39b99abeca00492d333734a0a25e605038b9225e9d99a84"
      "ab289bd74ded91decfb33d629ef702f2a4f62a7244ad5155711edb8e"
      "8465bacf348ef229e3f00b2b0e2a67b5bfcd003c6a0f617f8f95966c6f605def0e99a77f"
      "3c9c7fb33b7ef8722077c6b0f0361e7ebf19261e958bc21bf5f97cc0",
      "c08bfbec8da49969892fd67737242db35c5aa9bb0b6e76e9300e310027280e60e861f90f"
      "8dcfb3e7febc137f2a79152e3414d5f01efc237c6e8e98e7ad803ca9"
      "ddac4936f2d0bbfa45f1783c763a3cea7f8b8147df5b1f7be33664e1350864be0da41d21"
      "9f029046825c2a28e41260110c90a141ee20c0e0746794c085d8d506",
      "ec83d4d58ae477be42bea5600aa6c9f58aacd4c9ecce7a1136c98cc359d3fd3b45c8c11a"
      "b98a447f0e0bb04aee9950233e3bb188a011d42af181e111f136589f"
      "3223ffb3e2abc2e770f9ffd393677361e251893aff2331339b4769bbb5b2375b4ab6b6f2"
      "627126b5c8f97fdcfabd517f2ff703f2a4f6e32f21effeb8f6f3e3f2",
      "7e2f33f218d77efee7eeca44987854a2cee74ff225d1463975556aa78c8dfdd5dc5ae165"
      "211b1d3effc6583f6c1d0d86ffb8cf1e029f5bc8460e3f97f1e47f79"
      "4f9719798c2b8ff373194ff8b9ccc9fc47e879372d4346b69dc38ee58a868a9db3eccb39"
      "9fff1d8ff3f9f9e0713ef784f3f9c9fc9719ebcf8b5f4e8b47fddf60",
      "e279961ea95fbaf395a911cfbddf30e2a0ef91afbd711bd6c7e6e43b466c56371644ecf6"
      "40bdca8c7a4485bfa28e17163f6fbd2a94e6978b8b7b85a7f5adbdaa"
      "2b4a29515e8e0e3fff62ac1fb68e2ec37fdc670fa11f932d44bc1f6fc906f2e57df7c9f0"
      "78df4de7f3be3b0c3cde779f8dff5f8cf5c3d6f11dc37fdc670fe779",
      "5f25eeb1ece67151d24d0dd9f4749cf33ae7f5e1f2e4bcee09e7f57fe304c5010c3daae7"
      "29a3eedb64001eb5ff85e4f3d849252fdb39cbef11e3781f1007b56f"
      "af5fcc1f4b62ac8d80c13a9419794685afa28ec7cf4f46f3ff07f8eda1ba",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 13616U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum",    "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "PropertyList"};
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 5, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "Name",
                emlrtMxCreateString("onParamChangeCImpl"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp48f026d3_18ba_4f67_b85f_e1ec705d3e16/onParamChangeCImpl.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(738861.95910879632));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("resetCImpl"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath",
                emlrtMxCreateString(
                    "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
                    "tp48f026d3_18ba_4f67_b85f_e1ec705d3e16/resetCImpl.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(738861.95910879632));
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 2, "Name",
                emlrtMxCreateString("processEntryPoint"));
  emlrtSetField(xEntryPoints, 2, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 2, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 2, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 2, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp48f026d3_18ba_4f67_b85f_e1ec705d3e16/processEntryPoint.m"));
  emlrtSetField(xEntryPoints, 2, "TimeStamp",
                emlrtMxCreateDoubleScalar(738861.95910879632));
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 3, "Name",
                emlrtMxCreateString("createPluginInstance"));
  emlrtSetField(xEntryPoints, 3, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 3, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 3, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 3, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp48f026d3_18ba_4f67_b85f_e1ec705d3e16/createPluginInstance.m"));
  emlrtSetField(xEntryPoints, 3, "TimeStamp",
                emlrtMxCreateDoubleScalar(738861.95910879632));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 4, "Name",
                emlrtMxCreateString("getLatencyInSamplesCImpl"));
  emlrtSetField(xEntryPoints, 4, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 4, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 4, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 4, "FullPath",
      emlrtMxCreateString(
          "/private/var/folders/qr/sj71xk1x2ssd9mqyp27drwz00000gn/T/"
          "tp48f026d3_18ba_4f67_b85f_e1ec705d3e16/getLatencyInSamplesCImpl.m"));
  emlrtSetField(xEntryPoints, 4, "TimeStamp",
                emlrtMxCreateDoubleScalar(738861.95910879632));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("9.13.0.2049777 (R2022b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("6Yn06eHSjo4ZR4q4eMHRV"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_phasePlugin_info.cpp)
